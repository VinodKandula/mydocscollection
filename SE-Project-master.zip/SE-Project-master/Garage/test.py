import os
import sys

print(sys.argv[1])
