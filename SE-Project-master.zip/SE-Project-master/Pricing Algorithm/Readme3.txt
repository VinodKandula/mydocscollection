Dynamic Pricing algorithm
----------------------------------------------------------------------

Pre reqs

----------------------------------------------------------------------
In this python code, the program heavily relies on the math calculation, data visualization and I/O operation.

So before run this code, one should make sure the python libraries installed in the PC.

import csv
import numpy as np
from scipy.optimize import leastsq
import math
import matplotlib.pyplot as plt

make sure the other supporting files are also under the same directory


-----------------------------------------------------------------------
To test the dynamic pricing algorithm, type:
ptyhon dynamicPrice.py

Then, the code will run and show the figures.
Close one figure and the next figure will show up and so on so forth to the end.