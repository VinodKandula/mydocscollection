Unit Testing

the code is heavily modularized so unit testing is quite easy

each module is listed below and testing procedures

The testing procedure can be model mostly below:

result = function_name(parameters)
print(result)

The comments give detailed desciptions of function parameters and outputs
